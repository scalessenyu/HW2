package edu.nyu.homework.week2;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.widget.TextView;
import android.widget.Toast;

public class HomeworkWeek2Activity extends Activity {
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
    	
    	//call the superclass's onCreate
        super.onCreate(savedInstanceState);
        
        //set the view defined in main.xml
        setContentView(R.layout.main);
        
        //get the message defined in strings.xml
        String message = getString(R.string.message);
        
        //display the message in a TextView
        TextView textView = (TextView)findViewById(R.id.textView);
        textView.setText(message);
        
        //display the message as Toast
        Toast toast = Toast.makeText(this, message, Toast.LENGTH_LONG);
        toast.setGravity(Gravity.CENTER, 0, 0);
        toast.show();
        
        //display the message in the log
        Log.d("HW2", message);
        
    }
    
}